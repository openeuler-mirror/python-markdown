Installing Python-Markdown
==========================

As an Admin/Root user on your system do:

    pip install markdown

Or for more specific instructions, view the documentation in `docs/install.txt`
or on the website at <http://packages.python.org/Markdown/>.
